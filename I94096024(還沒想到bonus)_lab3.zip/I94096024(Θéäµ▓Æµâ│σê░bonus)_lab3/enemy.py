import pygame
import math
import os
from settings import PATH, PATH_2

pygame.init()
ENEMY_IMAGE = pygame.image.load(os.path.join("images", "enemy.png"))


class Enemy:
    def __init__(self):
        self.width = 40
        self.height = 50
        self.image = pygame.transform.scale(ENEMY_IMAGE, (self.width, self.height))
        self.health = 5
        self.max_health = 10
        #可以多多利用下面的參數
        self.path = PATH # 讀setting裡的資料
        self.path_pos = 0 # 總共有幾段
        self.move_count = 0 # 每一小段走幾步
        self.stride = 1 # length per step
        self.x, self.y = self.path[0] # start position

    def draw(self, win):
        # draw enemy
        win.blit(self.image, (self.x - self.width // 2, self.y - self.height // 2))
        # draw enemy health bar
        self.draw_health_bar(win)

    def draw_health_bar(self, win):
        """
        Draw health bar on an enemy
        :param win: window
        :return: None
        """
        # draw max health in red
        pygame.draw.rect(win, (255, 0, 0), [(self.x-20), (self.y-30), 50, 5])
        # draw health in green
        pygame.draw.rect(win, (0, 255, 0), [(self.x-20), (self.y-30),(self.health*5), 5])

    def change_route(self, num):
        if (num%2) == 1:
            self.path = PATH_2
            self.x, self.y = self.path[0]
        elif (num%2) == 0:
            self.path = PATH
            self.x, self.y = self.path[0]

    def move(self):
        """
        Enemy move toward path points every frame
        :return: None
        """

        # x, y position of point a
        ax, ay = self.path[self.path_pos]
        # x, y position of point b
        bx, by = self.path[self.path_pos+1]
        # define a counter to count the footstep
        # define how long per step
        stride = 1
        distance_a_b = math.sqrt((ax - bx) ** 2 + (ay - by) ** 2)
        # total footsteps that needed from a to b
        max_count = int(distance_a_b / stride)
        if self.move_count< max_count:
            #set unit vector to make sure a piont moving along the side
            unit_vector_x = (bx - ax) / distance_a_b
            unit_vector_y = (by - ay) / distance_a_b
            delta_x = unit_vector_x * stride
            delta_y = unit_vector_y * stride
            # update the coordinate and the counter
            self.x += delta_x
            self.y += delta_y
            self.move_count += 1
        else:
            self.path_pos += 1
            self.move_count = 0 # 到達下一個指示點時，步數歸零

class EnemyGroup:
    def __init__(self):
        self.gen_count = 0
        self.campaign_max_count = 120   # (unit: frame)
        self.reserved_members = []
        self.expedition = [Enemy()]  # don't change this line until you do the EX.3
        # show enemy(s) on win
        # 如果放三隻就會一次跑出三隻，所以應該是按時一隻一隻的放進去

    def campaign(self):
        """
        Send an enemy to go on an expedition once 120 frame
        :return: None
        """
        if self.reserved_members != []:
            if self.gen_count < self.campaign_max_count:
                self.gen_count += 1
            else:
                self.expedition.append(self.reserved_members.pop())
                self.gen_count = 0


    def generate(self, num):
        """
        Generate the enemies in this wave
        :param num: enemy number
        :return: None
        """

        for i in range (num):
            self.reserved_members.append(Enemy())

        # ...(to be done)

    def get(self):
        """
        Get the enemy list
        """
        return self.expedition

    def is_empty(self):
        """
        Return whether the enemy is empty (so that we can move on to next wave)
        """
        return False if self.reserved_members else True

    def retreat(self, enemy):
        """
        Remove the enemy from the expedition
        :param enemy: class Enemy()
        :return: None
        """
        self.expedition.remove(enemy)





